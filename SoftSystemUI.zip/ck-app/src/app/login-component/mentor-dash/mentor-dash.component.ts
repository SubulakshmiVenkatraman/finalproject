import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-dash',
  templateUrl: './mentor-dash.component.html',
  styleUrls: ['./mentor-dash.component.css']
})
export class MentorDashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
